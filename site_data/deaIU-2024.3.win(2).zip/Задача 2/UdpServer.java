import java.net.*;

public class UdpServer {
    public static void main(String[] args) {
        // Порт, на котором сервер будет слушать входящие сообщения
        int port = 9876;

        try {
            // Создаем объект DatagramSocket для прослушивания на указанном порту
            DatagramSocket socket = new DatagramSocket(port);
            System.out.println("UDP-сервер запущен и слушает на порту " + port);

            // Массив для хранения входящего сообщения
            byte[] receiveData = new byte[1024];

            while (true) {
                // Создаем пакет для получения данных от клиента
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                // Ожидаем получения пакета
                socket.receive(receivePacket);

                // Извлекаем сообщение из полученного пакета
                String message = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Получено сообщение от клиента: " + message);

                // Обрабатываем сообщение (например, просто добавляем " - ответ от сервера")
                String responseMessage = "Сервер получил: " + message;

                // Получаем адрес клиента и порт для отправки ответа
                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();

                // Преобразуем ответ в массив байтов
                byte[] sendData = responseMessage.getBytes();

                // Создаем пакет для отправки ответа клиенту
//DatagramPacket - пакет данных который можно отправить получить через udp senddate массив байтов потом длина
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
                // Отправляем ответ клиенту
                socket.send(sendPacket);
                System.out.println("Ответ отправлен клиенту: " + responseMessage);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Выводим информацию об ошибке
        }
    }
}
