import java.net.*;
import java.util.Scanner;

public class UdpClient {
    public static void main(String[] args) {
        // Адрес сервера и порт, к которому мы будем подключаться
        String serverAddress = "localhost"; // Используем localhost для локального тестирования
        int port = 9876;

        try {
            // Создаем объект DatagramSocket для отправки и получения данных
            DatagramSocket socket = new DatagramSocket();

            // Создаем объект Scanner для чтения ввода пользователя
            Scanner scanner = new Scanner(System.in);

            while (true) {
                // Запрашиваем сообщение у пользователя
                System.out.print("Введите сообщение для сервера (или 'exit' для выхода): ");
                String message = scanner.nextLine();

                // Если пользователь ввел 'exit', выходим из цикла
                if (message.equalsIgnoreCase("exit")) {
                    break;
                }

                // Преобразуем сообщение в массив байтов //тк udp аботает с байтами потому преобразуем
                byte[] sendData = message.getBytes();

                // Создаем пакет для отправки сообщения серверу
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, InetAddress.getByName(serverAddress), port);
                // Отправляем пакет на сервер
                socket.send(sendPacket);
                System.out.println("Сообщение отправлено серверу: " + message);

                // Массив для хранения ответа от сервера //когда клиент ждет ответ от сервера нужно место для хранения данных
                byte[] receiveData = new byte[1024];
                // Создаем пакет для получения ответа от сервера
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                // Ожидаем получения ответа от сервера
                socket.receive(receivePacket);

                // Извлекаем ответ из полученного пакета
                String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Ответ от сервера: " + response);
            }

            // Закрываем сокет и сканер
            socket.close();
            scanner.close();
            System.out.println("Клиент завершил работу.");
        } catch (Exception e) {
            e.printStackTrace(); // Выводим информацию об ошибке
        }
    }
}
