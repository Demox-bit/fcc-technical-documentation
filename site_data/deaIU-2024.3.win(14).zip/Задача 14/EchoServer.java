import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.net.InetSocketAddress;
import java.util.Iterator;

public class EchoServer {
    private Selector selector;
    private ServerSocketChannel serverSocketChannel;

    public EchoServer(int port) throws IOException {
        // Создаем селектор для управления каналами
        selector = Selector.open();
        
        // Создаем серверный сокет-канал
        serverSocketChannel = ServerSocketChannel.open();
        serverSocketChannel.bind(new InetSocketAddress(port));
        
        // Устанавливаем неблокирующий режим
        serverSocketChannel.configureBlocking(false);
        
        // Регистрация канала в селекторе для обработки новых подключений
        serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);
        
        System.out.println("Сервер запущен на порту: " + port);
    }

    public void start() throws IOException {
        while (true) {
            // Ожидание событий на каналах
            selector.select();

            // Получаем итератор для обработки ключей
            Iterator<SelectionKey> keyIterator = selector.selectedKeys().iterator();

            while (keyIterator.hasNext()) {
                SelectionKey key = keyIterator.next();
                keyIterator.remove(); // Удаляем ключ, чтобы избежать повторной обработки

                if (key.isAcceptable()) {
                    // Обработка нового подключения
                    acceptConnection(key);
                } else if (key.isReadable()) {
                    // Обработка входящих сообщений
                    readMessage(key);
                }
            }
        }
    }

    private void acceptConnection(SelectionKey key) throws IOException {
        // Получаем серверный сокет-канал
        ServerSocketChannel serverSocketChannel = (ServerSocketChannel) key.channel();
        
        // Принимаем новое соединение
        SocketChannel socketChannel = serverSocketChannel.accept();
        socketChannel.configureBlocking(false); // Устанавливаем неблокирующий режим
        
        // Регистрируем новый сокет-канал в селекторе для чтения
        socketChannel.register(selector, SelectionKey.OP_READ);
        
        System.out.println("Новое подключение: " + socketChannel.getRemoteAddress());
    }

    private void readMessage(SelectionKey key) throws IOException {
        // Получаем сокет-канал из ключа
        SocketChannel socketChannel = (SocketChannel) key.channel();
        ByteBuffer buffer = ByteBuffer.allocate(256); // Буфер для чтения данных

        // Читаем данные из канала
        int bytesRead = socketChannel.read(buffer);
        if (bytesRead == -1) {
            // Если клиент закрыл соединение
            System.out.println("Клиент отключился: " + socketChannel.getRemoteAddress());
            socketChannel.close();
            return;
        }

        // Подготовка данных к отправке обратно
        buffer.flip(); // Переключаем буфер на режим чтения
        socketChannel.write(buffer); // Отправляем данные обратно клиенту
        buffer.clear(); // Очищаем буфер для следующего чтения
    }

    public static void main(String[] args) {
        try {
            EchoServer server = new EchoServer(12345); // Запускаем сервер на порту 12345
            server.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
