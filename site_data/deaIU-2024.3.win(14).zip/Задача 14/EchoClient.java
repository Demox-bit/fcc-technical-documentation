import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.net.InetSocketAddress;
import java.util.Scanner;

public class EchoClient {
    private SocketChannel socketChannel;

    public EchoClient(String host, int port) throws IOException {
        // Подключаемся к серверу по указанному адресу и порту
        socketChannel = SocketChannel.open(new InetSocketAddress(host, port));
        socketChannel.configureBlocking(false); // Устанавливаем неблокирующий режим
        System.out.println("Подключено к серверу: " + host + ":" + port);
    }

    public void start() throws IOException {
        Scanner scanner = new Scanner(System.in);
        ByteBuffer buffer = ByteBuffer.allocate(256); // Буфер для отправки и получения данных

        while (true) {
            System.out.print("Введите сообщение (или 'exit' для выхода): ");
            String message = scanner.nextLine();

            if ("exit".equalsIgnoreCase(message)) {
                break; // Выход из цикла, если пользователь ввел 'exit'
            }

            // Отправляем сообщение на сервер
            buffer.clear(); // Очищаем буфер перед записью
            buffer.put(message.getBytes()); // Записываем сообщение в буфер
            buffer.flip(); // Переключаем буфер на режим чтения
            socketChannel.write(buffer); // Отправляем данные на сервер

            // Читаем ответ от сервера
            buffer.clear(); // Очищаем буфер для чтения
            int bytesRead;
            do {
                bytesRead = socketChannel.read(buffer); // Читаем ответ от сервера
            } while (bytesRead <= 0); // Ждем, пока сервер не отправит ответ

            buffer.flip(); // Переключаем буфер на режим чтения
            byte[] response = new byte[bytesRead];
            buffer.get(response); // Получаем ответ из буфера
            System.out.println("Ответ от сервера: " + new String(response)); // Выводим ответ
        }

        // Закрываем соединение
        socketChannel.close();
        scanner.close();
        System.out.println("Соединение закрыто.");
    }

    public static void main(String[] args) {
        try {
            EchoClient client = new EchoClient("localhost", 12345); // Подключаемся к серверу на localhost:12345
            client.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
