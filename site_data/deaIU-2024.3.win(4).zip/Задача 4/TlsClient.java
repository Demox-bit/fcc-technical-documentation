import javax.net.ssl.*;
import java.io.*;
import java.security.KeyStore;

public class TlsClient {
    public static void main(String[] args) {
        String serverAddress = "localhost"; // Адрес сервера
        int port = 12345; // Порт сервера

        try {
            // Загружаем хранилище ключей (если необходимо)
            KeyStore keyStore = KeyStore.getInstance("JKS");
            keyStore.load(new FileInputStream("keystore.jks"), "password".toCharArray());

            // Создаем SSLContext
            SSLContext sslContext = SSLContext.getInstance("TLS"); //ставим протокол
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm()); //управление доверенным сертификатом
            trustManagerFactory.init(keyStore);
            sslContext.init(null, trustManagerFactory.getTrustManagers(), null); //передаем доверенные сертификаты

            // Создаем SSLSocketFactory и сокет
            SSLSocketFactory socketFactory = sslContext.getSocketFactory(); //для создания ссл сокетов
            SSLSocket socket = (SSLSocket) socketFactory.createSocket(serverAddress, port); //собсна сам сокет для подключения
            System.out.println("Подключено к серверу: " + serverAddress + " на порту " + port);

            // Создаем потоки для общения с сервером
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            // Отправ ляем сообщение серверу
            String message = "Привет, сервер!";
            out.println(message);
            System.out.println("Сообщение отправлено серверу: " + message);

            // Читаем ответ от сервера
            String response = in.readLine();
            System.out.println("Ответ от сервера: " + response);

            // Закрываем соединение
            socket.close();
            System.out.println("Клиент завершил работу.");
        } catch (Exception e) {
            e.printStackTrace(); // Выводим информацию об ошибке
        }
    }
}
