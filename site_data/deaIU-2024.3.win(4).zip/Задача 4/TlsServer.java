import javax.net.ServerSocketFactory;
import javax.net.ssl.*;
import java.io.*;
import java.security.KeyStore;

public class TlsServer {
    public static void main(String[] args) {
        int port = 12345; // Порт, на котором сервер будет слушать

        try {
            // Загружаем хранилище ключей
            KeyStore keyStore = KeyStore.getInstance("JKS");
            keyStore.load(new FileInputStream("keystore.jks"), "password".toCharArray());

            // Создаем SSLContext с загруженным хранилищем ключей
            SSLContext sslContext = SSLContext.getInstance("TLS");
            //управляет хранилищем ключей. Он используется для предоставления ключей (например, сертификатов) для аутентификации сервера.
            KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            //передаем ключи сертификаты через keystore
            keyManagerFactory.init(keyStore, "password".toCharArray());
            sslContext.init(keyManagerFactory.getKeyManagers(), null, null);

            // Создаем SSLServerSocketFactory и серверный сокет
            ServerSocketFactory serverSocketFactory = sslContext.getServerSocketFactory();
            SSLServerSocket serverSocket = (SSLServerSocket) serverSocketFactory.createServerSocket(port);
            System.out.println("TLS-сервер запущен и слушает на порту " + port);

            while (true) {
                // Ожидаем подключения клиента
                SSLSocket clientSocket = (SSLSocket) serverSocket.accept();
                System.out.println("Клиент подключился: " + clientSocket.getInetAddress());

                // Создаем потоки для общения с клиентом
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

                // Читаем сообщение от клиента
                String message = in.readLine();
                System.out.println("Получено сообщение от клиента: " + message);

                // Обрабатываем сообщение (например, просто добавляем " - ответ от сервера")
                String response = "Сервер получил: " + message;

                // Отправляем ответ клиенту
                out.println(response);
                System.out.println("Ответ отправлен клиенту.");

                // Закрываем соединение с клиентом
                clientSocket.close();
            }
        } catch (Exception e) {
            e.printStackTrace(); // Выводим информацию об ошибке
        }
    }
}
