import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;
public class UdpEchoServer {
    public static void main(String[] args) {
        // Порт, на котором будет работать сервер
        int port = 9876;

        // Создаем объект DatagramChannel
        try (DatagramChannel channel = DatagramChannel.open()) {
            // Устанавливаем режим канала на неблокирующий
            channel.configureBlocking(false);

            // Привязываем канал к указанному порту
            channel.bind(new InetSocketAddress(port));
            System.out.println("UDP Echo Server запущен на порту " + port);

            // Создаем буфер для хранения входящих данных
            ByteBuffer buffer = ByteBuffer.allocate(1024);

            while (true) {
                // Очистка буфера перед чтением новых данных
                buffer.clear();

                // Получаем адрес клиента и читаем данные
                InetSocketAddress clientAddress = (InetSocketAddress) channel.receive(buffer);

                // Проверяем, есть ли данные от клиента
                if (clientAddress != null) {
                    // Переводим буфер в режим чтения
                    buffer.flip();

                    // Отправляем данные обратно клиенту
                    channel.send(buffer, clientAddress);
                    System.out.println("Отправлено обратно клиенту: " + clientAddress);
                }

                // Не забываем делать паузу, чтобы не загружать процессор
                Thread.sleep(100);
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
