import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
public class UdpEchoClient {
    public static void main(String[] args) {
        // Адрес сервера и порт, на котором он работает
        String serverAddress = "localhost"; // или IP-адрес сервера
        int serverPort = 9876;

        // Создаем сокет для отправки и получения UDP-пакетов
        try (DatagramSocket socket = new DatagramSocket()) {
            // Сообщение, которое мы хотим отправить
            String message = "Привет, сервер!";
            byte[] sendData = message.getBytes(StandardCharsets.UTF_8);

            // Создаем пакет для отправки
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length,
                    InetAddress.getByName(serverAddress), serverPort);

            // Отправляем пакет
            socket.send(sendPacket);
            System.out.println("Отправлено на сервер: " + message);

            // Буфер для получения ответа
            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

            // Получаем ответ от сервера
            socket.receive(receivePacket);
//1 возвращает массив байт + 0 это начальный индекс для чтения + количество байтов в пакете
//Этот метод возвращает количество байтов, которые фактически были получены в пакете. Это важно, потому что, когда мы получаем данные, они могут занимать не весь массив. Например, если мы отправили 20 байтов, но массив имеет размер 1024, то только первые 20 байтов будут содержать данные, а остальные 1000 будут пустыми (или нулями). Используя getLength(), мы указываем, сколько байтов нам нужно преобразовать в строку.
            String receivedMessage = new String(receivePacket.getData(), 0, receivePacket.getLength(), StandardCharsets.UTF_8);
            System.out.println("Получено от сервера: " + receivedMessage);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
