import java.io.IOException;
import java.net.InetAddress;

public class PingUtility {

    public static void main(String[] args) {
        // Проверяем, что передан аргумент с IP-адресом
        if (args.length != 1) {
            System.out.println("Использование: java PingUtility <IP-адрес>");
            return;
        }

        String ipAddress = args[0];

        try {
            // Получаем объект InetAddress для указанного IP-адреса
            InetAddress address = InetAddress.getByName(ipAddress);

            // Отправляем ICMP-запрос и проверяем доступность адреса
            System.out.println("Отправка ICMP-запроса на " + ipAddress + "...");
            long startTime = System.currentTimeMillis(); //  Этот метод возвращает текущее время в миллисекундах с начала эпохи (1 января 1970 года, 00:00:00 UTC)
            boolean reachable = address.isReachable(5000); // Таймаут 5 секунд метод пытается установить соединение с указанным IP-адресом, отправляя ICMP-запрос (ping)
            long endTime = System.currentTimeMillis(); // После выполнения метода isReachable, мы снова вызываем System.currentTimeMillis(), чтобы получить текущее время и сохранить его в переменной endTime. Это позволяет нам зафиксировать момент времени, когда мы получили ответ (или истек таймаут).



            // Выводим результат
            if (reachable) {
                System.out.println("Ответ от " + ipAddress + ": время=" + (endTime - startTime) + "мс");
            } else {
                System.out.println("Не удалось достучаться до " + ipAddress);
            }
        } catch (IOException e) {
            System.out.println("Ошибка: " + e.getMessage());
        }
    }
}

