import java.io.*;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FileServer {

    private static final int PORT = 12345; // Порт, на котором будет работать сервер
    private static final String FILE_DIRECTORY = "server_files"; // Директория для хранения файлов

    public static void main(String[] args) {
        // Создаем директорию для файлов, если она не существует
        File directory = new File(FILE_DIRECTORY);
        if (!directory.exists()) {
            directory.mkdir();
        }

        // Создаем пул потоков для обработки клиентов
        ExecutorService executor = Executors.newFixedThreadPool(10);

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Сервер запущен на порту: " + PORT);

            while (true) {
                // Ожидание подключения клиента
                Socket clientSocket = serverSocket.accept();
                System.out.println("Клиент подключен: " + clientSocket.getInetAddress());

                // Передаем клиентский сокет в новый поток для обработки запроса
                executor.execute(new ClientHandler(clientSocket));
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            executor.shutdown();
        }
    }

    // Метод для получения директории файлов
    public static String getFileDirectory() {
        return FILE_DIRECTORY;
    }
}

class ClientHandler implements Runnable {
    private Socket clientSocket;

    public ClientHandler(Socket socket) {
        this.clientSocket = socket;
    }

    @Override
    public void run() {
        try (DataInputStream in = new DataInputStream(clientSocket.getInputStream());
             DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream())) {

            // Читаем команду от клиента
            String command = in.readUTF();
            if (command.equals("UPLOAD")) {
                handleFileUpload(in, out);
            } else if (command.equals("DOWNLOAD")) {
                handleFileDownload(in, out);
            } else {
                out.writeUTF("Неверная команда");
            }

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void handleFileUpload(DataInputStream in, DataOutputStream out) throws IOException {
        // Получаем имя файла от клиента
        String fileName = in.readUTF();
        long fileSize = in.readLong();

        // Создаем файл для сохранения
        File file = new File(FileServer.getFileDirectory(), fileName);
        try (FileOutputStream fos = new FileOutputStream(file)) {
            byte[] buffer = new byte[4096];
            long totalBytesRead = 0;

            // Читаем данные из сокета и записываем в файл
            while (totalBytesRead < fileSize) {
                int bytesRead = in.read(buffer, 0, Math.min(buffer.length, (int)(fileSize - totalBytesRead)));
                if (bytesRead == -1) break; // Достигнут конец потока
                fos.write(buffer, 0, bytesRead);
                totalBytesRead += bytesRead;
            }
        }

        out.writeUTF("Файл загружен: " + fileName);
    }

    private void handleFileDownload(DataInputStream in, DataOutputStream out) throws IOException {
        // Получаем имя файла от клиента
        String fileName = in.readUTF();
        File file = new File(FileServer.getFileDirectory(), fileName);

        if (!file.exists()) {
            out.writeUTF("Файл не найден");
            return;
        }

        // Отправляем информацию о файле
        out.writeUTF("OK");
        out.writeLong(file.length());

        // Читаем файл и отправляем его клиенту
        try (FileInputStream fis = new FileInputStream(file)) {
            byte[] buffer = new byte[4096];
            int bytesRead;

            while ((bytesRead = fis.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }

        out.writeUTF("Файл загружен: " + fileName);
    }
}
