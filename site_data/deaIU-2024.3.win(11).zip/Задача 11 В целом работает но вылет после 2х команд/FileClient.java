import java.io.*;
import java.net.*;
import java.util.Scanner;

public class FileClient {

    private static final String SERVER_ADDRESS = "localhost"; // Адрес сервера
    private static final int SERVER_PORT = 12345; // Порт сервера

    public static void main(String[] args) {
        try (Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
             DataInputStream in = new DataInputStream(socket.getInputStream());
             DataOutputStream out = new DataOutputStream(socket.getOutputStream());
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Подключено к серверу: " + SERVER_ADDRESS + ":" + SERVER_PORT);

            while (true) {
                System.out.println("Введите команду (UPLOAD, DOWNLOAD, EXIT): ");
                String command = scanner.nextLine().trim().toUpperCase();

                if (command.equals("EXIT")) {
                    break; // Выход из программы
                }

                out.writeUTF(command); // Отправляем команду на сервер

                if (command.equals("UPLOAD")) {
                    handleFileUpload(scanner, out, in);
                } else if (command.equals("DOWNLOAD")) {
                    handleFileDownload(scanner, out, in);
                } else {
                    System.out.println("Неверная команда. Попробуйте еще раз.");
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleFileUpload(Scanner scanner, DataOutputStream out, DataInputStream in) throws IOException {
        System.out.println("Введите имя файла для загрузки: ");
        String fileName = scanner.nextLine().trim();

        File file = new File(fileName);
        if (!file.exists() || !file.isFile()) {
            System.out.println("Файл не найден.");
            return;
        }

        // Отправляем имя файла и его размер
        out.writeUTF(file.getName());
        out.writeLong(file.length());

        // Читаем файл и отправляем его на сервер
        try (FileInputStream fis = new FileInputStream(file)) {
            byte[] buffer = new byte[4096];
            int bytesRead;

            while ((bytesRead = fis.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        }

        // Получаем ответ от сервера
        String response = in.readUTF();
        System.out.println(response);
    }

    private static void handleFileDownload(Scanner scanner, DataOutputStream out, DataInputStream in) throws IOException {
        System.out.println("Введите имя файла для скачивания: ");
        String fileName = scanner.nextLine().trim();

        // Отправляем имя файла на сервер
        out.writeUTF(fileName);

        // Получаем ответ от сервера
        String response = in.readUTF();
        if (response.equals("OK")) {
            long fileSize = in.readLong();
            System.out.println("Размер файла: " + fileSize + " байт");

            // Создаем файл для сохранения
            File file = new File(fileName);
            try (FileOutputStream fos = new FileOutputStream(file)) {
                byte[] buffer = new byte[4096];
                long totalBytesRead = 0;

                // Читаем данные из сокета и записываем в файл
                while (totalBytesRead < fileSize) {
                    int bytesRead = in.read(buffer, 0, Math.min(buffer.length, (int)(fileSize - totalBytesRead)));
                    if (bytesRead == -1) break; // Достигнут конец потока
                    fos.write(buffer, 0, bytesRead);
                    totalBytesRead += bytesRead;
                }
            }

            // Получаем финальный ответ от сервера
            response = in.readUTF();
            System.out.println(response);
        } else {
            System.out.println(response); // Сообщение о том, что файл не найден
        }
    }
}
