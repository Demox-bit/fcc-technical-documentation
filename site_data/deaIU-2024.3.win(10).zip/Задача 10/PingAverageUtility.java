import java.io.IOException;
import java.net.InetAddress;

public class PingAverageUtility {

    public static void main(String[] args) {
        // Проверяем, что передан аргумент с IP-адресом
        if (args.length != 2) {
            System.out.println("Использование: java PingAverageUtility <IP-адрес> <количество пакетов>");
            return;
        }

        String ipAddress = args[0];
        int packetCount;

        // Пробуем преобразовать второй аргумент в целое число
        try {
            packetCount = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            System.out.println("Количество пакетов должно быть целым числом.");
            return;
        }

        long totalTime = 0;
        int successfulPings = 0;

        try {
            // Получаем объект InetAddress для указанного IP-адреса
            InetAddress address = InetAddress.getByName(ipAddress);

            // Отправляем ICMP-запросы ping
            for (int i = 0; i < packetCount; i++) {
                System.out.println("Отправка ICMP-запроса на " + ipAddress + "...");
                long startTime = System.currentTimeMillis();
                boolean reachable = address.isReachable(5000); // Таймаут 5 секунд
                long endTime = System.currentTimeMillis();

                // Выводим результат
                if (reachable) {
                    long responseTime = endTime - startTime;
                    System.out.println("Ответ от " + ipAddress + ": время=" + responseTime + "мс");
                    totalTime += responseTime;
                    successfulPings++;
                } else {
                    System.out.println("Не удалось достучаться до " + ipAddress);
                }

                // Задержка между запросами (например, 1 секунда)
                Thread.sleep(1000);
            }

            // Вычисляем среднее время отклика
            if (successfulPings > 0) {
                double averageTime = (double) totalTime / successfulPings;
                System.out.println("Среднее время отклика: " + averageTime + "мс");
            } else {
                System.out.println("Не было успешных ответов.");
            }
        } catch (IOException | InterruptedException e) {
            System.out.println("Ошибка: " + e.getMessage());
        }
    }
}

