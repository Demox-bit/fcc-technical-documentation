import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

public class UDPServer {
    private static final int PORT = 9876; // Порт для сервера
    private static List<InetAddress> clientAddresses = new ArrayList<>(); // Список адресов клиентов
    private static List<Integer> clientPorts = new ArrayList<>(); // Список портов клиентов

    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket(PORT)) {
            System.out.println("Сервер запущен на порту " + PORT);

            while (true) {
                // Буфер для получения данных
                byte[] receiveBuffer = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                
                // Получаем сообщение от клиента
                socket.receive(receivePacket);
                String message = new String(receivePacket.getData(), 0, receivePacket.getLength());
                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();

                // Добавляем адрес и порт клиента в списки, если их там еще нет
                if (!clientAddresses.contains(clientAddress) || !clientPorts.contains(clientPort)) {
                    clientAddresses.add(clientAddress);
                    clientPorts.add(clientPort);
                }

                System.out.println("Получено сообщение: " + message + " от " + clientAddress + ":" + clientPort);

                // Рассылаем сообщение всем подключенным клиентам
                for (int i = 0; i < clientAddresses.size(); i++) {
                    InetAddress address = clientAddresses.get(i);
                    int port = clientPorts.get(i);
                    if (!(address.equals(clientAddress) && port == clientPort)) {
                        // Отправляем сообщение
                        DatagramPacket sendPacket = new DatagramPacket(receivePacket.getData(), receivePacket.getLength(), address, port);
                        socket.send(sendPacket);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
