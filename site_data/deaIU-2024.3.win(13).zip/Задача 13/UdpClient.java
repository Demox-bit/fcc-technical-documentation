import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class UDPClient {
    private static final String SERVER_ADDRESS = "localhost"; // Адрес сервера
    private static final int SERVER_PORT = 9876; // Порт сервера
    private static final int CLIENT_PORT = 0; // Порт клиента, система выберет доступный

    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket(CLIENT_PORT)) {
            System.out.println("Клиент запущен на порту " + socket.getLocalPort()); // Печатаем фактический порт

            // Создаем поток для получения сообщений от сервера
            new Thread(() -> {
                try {
                    while (true) {
                        byte[] receiveBuffer = new byte[1024];
                        DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                        socket.receive(receivePacket);
                        String message = new String(receivePacket.getData(), 0, receivePacket.getLength());
                        System.out.println("Получено сообщение от сервера: " + message);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }).start();

            // Читаем сообщения от пользователя и отправляем их на сервер
            Scanner scanner = new Scanner(System.in);
            while (true) {
                String message = scanner.nextLine();
                byte[] sendBuffer = message.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendBuffer, sendBuffer.length, InetAddress.getByName(SERVER_ADDRESS), SERVER_PORT);
                socket.send(sendPacket);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
