import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        // Адрес сервера и порт, к которому мы будем подключаться
        String serverAddress = "localhost"; // Используем localhost для локального тестирования
        int port = 12345;

        try {
            // Создаем сокет для подключения к серверу
            Socket socket = new Socket(serverAddress, port);
            System.out.println("Подключено к серверу: " + serverAddress + " на порту " + port);

            // Создаем потоки ввода и вывода для общения с сервером
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            // Отправляем сообщение серверу
            String message = "Привет, сервер!";
            out.println(message);
            System.out.println("Сообщение отправлено серверу: " + message);

            // Читаем ответ от сервера
            String response = in.readLine();
            System.out.println("Ответ от сервера: " + response);

            // Закрываем соединение
            socket.close();
            System.out.println("Соединение закрыто.");
        } catch (IOException e) {
            e.printStackTrace(); // Выводим информацию об ошибке
        }
    }
}
