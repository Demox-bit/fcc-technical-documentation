import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) {
        // Порт, на котором сервер будет слушать входящие соединения
        int port = 12345;

        try {
            // Создаем объект ServerSocket, который будет слушать на указанном порту
            ServerSocket serverSocket = new ServerSocket(port);
            System.out.println("Сервер запущен и слушает на порту " + port);

            // Бесконечный цикл для постоянного ожидания входящих соединений
            while (true) {
                // Ожидаем соединения от клиента
                Socket clientSocket = serverSocket.accept();
                System.out.println("Клиент подключился: " + clientSocket.getInetAddress());

                // Создаем потоки ввода и вывода для общения с клиентом
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

                // Читаем сообщение от клиента
                String message = in.readLine();
                System.out.println("Получено сообщение от клиента: " + message);

                // Отправляем ответ клиенту
                String response = "Сервер получил: " + message;
                out.println(response);
                System.out.println("Ответ отправлен клиенту.");

                // Закрываем соединение с клиентом
                clientSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace(); // Выводим информацию об ошибке
        }
    }
}
