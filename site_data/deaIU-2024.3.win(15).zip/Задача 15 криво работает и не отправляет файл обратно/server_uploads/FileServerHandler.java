import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.*;
import io.netty.handler.stream.ChunkedFile;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.RandomAccessFile;
import java.io.IOException;

public class FileServerHandler extends SimpleChannelInboundHandler<FullHttpRequest> {

    private final String fileDirectory;

    public FileServerHandler(String fileDirectory) {
        this.fileDirectory = fileDirectory;
    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, FullHttpRequest request) {
        String uri = request.uri();
        File file = new File(fileDirectory, uri);

        System.out.println("Requested file: " + file.getAbsolutePath());

        if (!file.exists() || !file.isFile()) {
            System.out.println("File not found: " + file.getAbsolutePath());
            ctx.writeAndFlush(new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.NOT_FOUND));
            return;
        }

        try {
            RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
            long fileLength = randomAccessFile.length();

            // Создаем HTTP-ответ
            FullHttpResponse response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.OK);
            response.headers().set(HttpHeaderNames.CONTENT_TYPE, "application/octet-stream");
            response.headers().set(HttpHeaderNames.CONTENT_LENGTH, fileLength);

            // Отправляем ответ
            ctx.write(response);

            // Отправляем содержимое файла
            ctx.write(new ChunkedFile(randomAccessFile));
            ctx.writeAndFlush(LastHttpContent.EMPTY_LAST_CONTENT).addListener(future -> {
                if (future.isSuccess()) {
                    System.out.println("File sent successfully: " + file.getAbsolutePath());
                } else {
                    System.out.println("Failed to send file: " + file.getAbsolutePath());
                }
                ctx.close();
            });
        } catch (FileNotFoundException e) {
            System.out.println("File not found exception: " + e.getMessage());
            ctx.writeAndFlush(new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.NOT_FOUND));
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("IO exception: " + e.getMessage());
            ctx.writeAndFlush(new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.INTERNAL_SERVER_ERROR));
            e.printStackTrace();
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        cause.printStackTrace();
        ctx.close();
    }
}

