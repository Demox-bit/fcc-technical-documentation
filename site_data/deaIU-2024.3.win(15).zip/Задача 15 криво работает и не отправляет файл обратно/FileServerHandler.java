import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.*;
import io.netty.util.CharsetUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class FileServerHandler extends SimpleChannelInboundHandler<FullHttpRequest> {

    private final String fileDirectory;

    public FileServerHandler(String fileDirectory) {
        this.fileDirectory = fileDirectory;
    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, FullHttpRequest request) {
        String uri = request.uri();
        File file = new File(fileDirectory, uri);

        System.out.println("Requested file: " + file.getAbsolutePath());

        if (!file.exists() || !file.isFile()) {
            System.out.println("File not found: " + file.getAbsolutePath());
            ctx.writeAndFlush(new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.NOT_FOUND));
            return;
        }

        try (FileInputStream fis = new FileInputStream(file);
             FileChannel fileChannel = fis.getChannel()) {

            long fileLength = fileChannel.size();
            System.out.println("File length: " + fileLength);

            // Создаем HTTP-ответ
            FullHttpResponse response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.OK);
            response.headers().set(HttpHeaderNames.CONTENT_TYPE, "application/octet-stream");
            HttpUtil.setContentLength(response, fileLength); // Устанавливаем длину содержимого

            // Отправляем ответ
            ctx.write(response);

            // Создаем буфер для чтения файла
            ByteBuffer buffer = ByteBuffer.allocate(8192); // 8 KB
            int bytesRead;
            while ((bytesRead = fileChannel.read(buffer)) > 0) {
                buffer.flip(); // Подготовка буфера для записи
                ByteBuf byteBuf = ctx.alloc().buffer(buffer.remaining());
                byteBuf.writeBytes(buffer);
                ctx.write(byteBuf);
                buffer.clear(); // Очистка буфера для следующего чтения
            }

            // Отправляем последний контент
            ctx.writeAndFlush(LastHttpContent.EMPTY_LAST_CONTENT).addListener(future -> {
                if (future.isSuccess()) {
                    System.out.println("File sent successfully: " + file.getAbsolutePath());
                } else {
                    System.out.println("Failed to send file: " + file.getAbsolutePath());
                }
                ctx.close();
            });
        } catch (FileNotFoundException e) {
            System.out.println("File not found exception: " + e.getMessage());
            ctx.writeAndFlush(new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.NOT_FOUND));
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("IO exception: " + e.getMessage());
            ctx.writeAndFlush(new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.INTERNAL_SERVER_ERROR));
            e.printStackTrace();
        }
    }


    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        cause.printStackTrace();
        ctx.close();
    }
}
