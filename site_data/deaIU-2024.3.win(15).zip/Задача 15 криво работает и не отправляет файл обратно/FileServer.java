import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.LengthFieldBasedFrameDecoder;
import io.netty.handler.codec.LengthFieldPrepender;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpRequestDecoder;
import io.netty.handler.codec.http.HttpResponseEncoder;
import io.netty.handler.stream.ChunkedWriteHandler;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;

public class FileServer {

    private final int port; // Порт, на котором будет запущен сервер
    private final String fileDirectory; // Директория, из которой будут отправляться файлы

    public FileServer(int port, String fileDirectory) {
        this.port = port;
        this.fileDirectory = fileDirectory;
    }

    public void start() throws InterruptedException {
        // Создаем группы потоков для обработки входящих соединений
        EventLoopGroup bossGroup = new NioEventLoopGroup(); // Группа для обработки входящих соединений
        EventLoopGroup workerGroup = new NioEventLoopGroup(); // Группа для обработки входящих запросов

        try {
            ServerBootstrap b = new ServerBootstrap(); // Создаем серверный бутстрап
            b.group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel.class) // Используем NIO для работы с сокетами
                    .childHandler(new ChannelInitializer<SocketChannel>() { // Инициализируем канал
                        @Override
                        protected void initChannel(SocketChannel ch) {
                            ch.pipeline().addLast(new HttpResponseEncoder()); // Кодировщик HTTP-ответов
                            ch.pipeline().addLast(new HttpRequestDecoder()); // Декодировщик HTTP-запросов
                            ch.pipeline().addLast(new HttpObjectAggregator(1048576)); // Агрегатор для объединения частей HTTP-сообщений
                            ch.pipeline().addLast(new ChunkedWriteHandler()); // Обработчик для отправки больших файлов
                            ch.pipeline().addLast(new FileServerHandler(fileDirectory)); // Обработчик запросов к файлам
                        }
                    })
                    .option(ChannelOption.SO_BACKLOG, 128) // Максимальное количество ожидающих соединений
                    .childOption(ChannelOption.SO_KEEPALIVE, true); // Включаем поддержку keep-alive

            ChannelFuture f = b.bind(port).sync(); // Привязываем сервер к порту и ждем завершения
            System.out.println("File server started on port: " + port); // Сообщение о запуске сервера
            f.channel().closeFuture().sync(); // Ждем закрытия канала
        } finally {
            // Завершаем работу групп потоков
            workerGroup.shutdownGracefully();
            bossGroup.shutdownGracefully();
        }
    }

    public static void main(String[] args) throws InterruptedException {
        // Проверяем, что переданы необходимые аргументы
        if (args.length < 2) {
            System.err.println("Usage: " + FileServer.class.getSimpleName() + " <port> <file-directory>");
            return;
        }
        int port = Integer.parseInt(args[0]); // Порт из аргументов
        String fileDirectory = args[1]; // Директория из аргументов
        new FileServer(port, fileDirectory).start(); // Создаем и запускаем сервер
    }
}
