import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
public class UdpMulticastServer {
    public static void main(String[] args) {
        // Многоадресный IP-адрес и порт
        String multicastAddress = "230.0.0.0"; // Пример многоадресного IP-адреса
        int port = 9876;

        try (DatagramSocket socket = new DatagramSocket()) {
            // Подготовка сообщения
            String message = "Привет, клиенты!";
            byte[] sendData = message.getBytes();

            // Создаем пакет для отправки
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length,
                    InetAddress.getByName(multicastAddress), port);

            // Отправляем сообщение каждые 2 секунды
            while (true) {
                socket.send(sendPacket);
                System.out.println("Сообщение отправлено: " + message);
                Thread.sleep(2000); // Пауза перед следующей отправкой
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
