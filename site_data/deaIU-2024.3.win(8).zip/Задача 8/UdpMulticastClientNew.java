import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.SocketAddress;
import java.net.InetSocketAddress;
/*

    Создание SocketAddress: Мы создаем объект SocketAddress, используя InetSocketAddress, который принимает многоадресный IP-адрес и порт.

    Указание сетевого интерфейса: Мы используем NetworkInterface.getByName("eth0") для получения сетевого интерфейса. Вам нужно заменить "eth0" на имя интерфейса вашей сети. Например, на Windows это может быть "Wi-Fi" или "Ethernet", а на Linux — "wlan0" или "eth0".

    Использование нового метода joinGroup: Теперь мы вызываем joinGroup с двумя параметрами: socketAddress и networkInterface.
*/
public class UdpMulticastClient {
    public static void main(String[] args) {
        // Многоадресный IP-адрес и порт
        String multicastAddress = "230.0.0.0"; // Тот же многоадресный IP-адрес
        int port = 9876;

        try {
            // Создаем многоадресный сокет для приема сообщений
            MulticastSocket socket = new MulticastSocket(port);

            // Присоединяемся к многоадресной группе
            InetAddress group = InetAddress.getByName(multicastAddress);
            SocketAddress socketAddress = new InetSocketAddress(group, port);
            NetworkInterface networkInterface = NetworkInterface.getByName("eth1"); // Укажите интерфейс вашей сети (например, "eth0", "wlan0" и т.д.)

            socket.joinGroup(socketAddress, networkInterface);

            // Буфер для получения данных
            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

            System.out.println("Клиент запущен и ожидает сообщения...");

            // Цикл для получения сообщений
            while (true) {
                socket.receive(receivePacket); // Ожидаем сообщения
                String receivedMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Получено сообщение: " + receivedMessage);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
