import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
/*
Предупреждение о том, что метод joinGroup(InetAddress) устарел, связано с тем, что в новых версиях Java рекомендуется использовать метод joinGroup(SocketAddress, NetworkInterface) для большей гибкости и контроля.

Чтобы избавиться от этого предупреждения, мы можем использовать метод joinGroup с двумя параметрами: SocketAddress и NetworkInterface. Это позволит нам явно указать сетевой интерфейс, через который будет происходить многоадресная рассылка.
*/
public class UdpMulticastClient {
    public static void main(String[] args) {
        // Многоадресный IP-адрес и порт
        String multicastAddress = "230.0.0.0"; // Тот же многоадресный IP-адрес
        int port = 9876;

        try {
            // Создаем многоадресный сокет для приема сообщений
            MulticastSocket socket = new MulticastSocket(port);

            // Присоединяемся к многоадресной группе
            InetAddress group = InetAddress.getByName(multicastAddress);
            socket.joinGroup(group);

            // Буфер для получения данных
            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

            System.out.println("Клиент запущен и ожидает сообщения...");

            // Цикл для получения сообщений
            while (true) {
                socket.receive(receivePacket); // Ожидаем сообщения
                String receivedMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());
                System.out.println("Получено сообщение: " + receivedMessage);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
