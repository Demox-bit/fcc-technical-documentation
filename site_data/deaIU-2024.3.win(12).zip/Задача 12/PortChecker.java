import java.io.IOException; // Импортируем класс IOException для обработки исключений
import java.net.DatagramPacket; // Импортируем класс DatagramPacket для работы с UDP
import java.net.DatagramSocket; // Импортируем класс DatagramSocket для работы с UDP
import java.net.InetAddress; // Импортируем класс InetAddress для работы с IP-адресами
import java.net.Socket; // Импортируем класс Socket для работы с TCP

public class PortChecker {

    // Метод для проверки TCP порта
    public static boolean isTcpPortOpen(String ipAddress, int port) {
        // Создаем переменную для сокета
        Socket socket = null;
        try {
            // Создаем новый сокет и пытаемся подключиться к указанному IP и порту
            socket = new Socket(ipAddress, port);
            // Если соединение установлено, возвращаем true
            return true;
        } catch (IOException e) {
            // Если возникло исключение, значит порт закрыт, возвращаем false
            return false;
        } finally {
            // Закрываем сокет, если он был открыт
            if (socket != null) {
                try {
                    socket.close();
                } catch (IOException e) {
                    // Игнорируем исключение при закрытии сокета
                }
            }
        }
    }

    // Метод для проверки UDP порта
    public static boolean isUdpPortOpen(String ipAddress, int port) {
        DatagramSocket socket = null;
        try {
            // Создаем новый DatagramSocket для отправки и получения UDP пакетов
            socket = new DatagramSocket();
            socket.setSoTimeout(2000); // Устанавливаем таймаут в 2 секунды

            // Создаем пустой пакет для отправки
            byte[] buf = new byte[256];
            InetAddress address = InetAddress.getByName(ipAddress);

            // Создаем пакет и отправляем его на указанный IP и порт
            DatagramPacket packet = new DatagramPacket(buf, buf.length, address, port);
            socket.send(packet); // Отправляем пакет

            // Создаем пакет для получения ответа
            DatagramPacket response = new DatagramPacket(buf, buf.length);
            socket.receive(response); // Ждем ответа

            // Если мы получили ответ, возвращаем true
            return true;
        } catch (IOException e) {
            // Если возникло исключение, значит порт закрыт или не отвечает, возвращаем false
            return false;
        } finally {
            // Закрываем сокет, если он был открыт
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        }
    }

    public static void main(String[] args) {
        // Проверяем, что переданы аргументы командной строки
        if (args.length != 3) {
            System.out.println("Usage: java PortChecker <IP> <port> <protocol>");
            System.out.println("protocol: tcp or udp");
            return; // Выходим из программы, если аргументы не корректны
        }

        String ipAddress = args[0]; // Получаем IP-адрес из аргументов
        int port = Integer.parseInt(args[1]); // Получаем порт и преобразуем его в целое число
        String protocol = args[2].toLowerCase(); // Получаем протокол и преобразуем его в нижний регистр

        // Проверяем указанный протокол и вызываем соответствующий метод
        if (protocol.equals("tcp")) {
            boolean isOpen = isTcpPortOpen(ipAddress, port);
            System.out.println("TCP Port " + port + " on " + ipAddress + " is " + (isOpen ? "open" : "closed"));
        } else if (protocol.equals("udp")) {
            boolean isOpen = isUdpPortOpen(ipAddress, port);
            System.out.println("UDP Port " + port + " on " + ipAddress + " is " + (isOpen ? "open" : "closed"));
        } else {
            System.out.println("Invalid protocol. Use 'tcp' or 'udp'.");
        }
    }
}
