import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.*;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.concurrent.GlobalEventExecutor;

public class ChatServer {

    // Группа каналов для хранения подключенных клиентов
    protected static final ChannelGroup channels = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

    public static void main(String[] args) throws Exception {
        // Создаем группу потоков для обработки входящих соединений
        EventLoopGroup bossGroup = new NioEventLoopGroup();
        EventLoopGroup workerGroup = new NioEventLoopGroup();
        try {
            // Создаем серверный бустер
            ServerBootstrap b = new ServerBootstrap();
            b.group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel.class)
                    .childHandler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        public void initChannel(SocketChannel ch) {
                            // Добавляем обработчик для обработки сообщений
                            ch.pipeline().addLast(new ChatServerHandler());
                        }
                    });

            // Запускаем сервер на порту 8080
            ChannelFuture f = b.bind(8080).sync();
            System.out.println("Chat server started on port: 8080");

            // Ждем завершения работы сервера
            f.channel().closeFuture().sync();
        } finally {
            // Завершаем работу групп потоков
            workerGroup.shutdownGracefully();
            bossGroup.shutdownGracefully();
        }
    }
}