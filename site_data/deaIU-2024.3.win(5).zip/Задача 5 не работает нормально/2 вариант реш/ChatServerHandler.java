import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import io.netty.channel.group.ChannelGroup;

public class ChatServerHandler extends ChannelInboundHandlerAdapter {

    @Override
    public void channelActive(ChannelHandlerContext ctx) {
        // Добавляем новый канал в группу и уведомляем всех клиентов
        ChatServer.channels.add(ctx.channel());
        System.out.println("Client connected: " + ctx.channel().remoteAddress());
        broadcast("Client connected: " + ctx.channel().remoteAddress());
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) {
        // Получаем адрес клиента и сообщение
        String message = msg.toString();
        String clientAddress = ctx.channel().remoteAddress().toString();
        System.out.println("Received message from client " + clientAddress + ": " + message);

        // Пересылаем сообщение всем остальным клиентам
        broadcast("Message from " + clientAddress + ": " + message);
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) {
        // Удаляем канал из группы и уведомляем всех клиентов
        ChatServer.channels.remove(ctx.channel());
        System.out.println("Client disconnected: " + ctx.channel().remoteAddress());
        broadcast("Client disconnected: " + ctx.channel().remoteAddress());
    }

    private void broadcast(String message) {
        // Пересылаем сообщение всем подключенным клиентам
        for (var channel : ChatServer.channels) {
            channel.writeAndFlush(message + "\n");
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        // Закрываем канал при возникновении исключения
        cause.printStackTrace();
        ctx.close();
    }
}