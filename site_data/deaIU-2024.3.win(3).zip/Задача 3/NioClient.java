import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;
import java.util.Scanner;

public class NioClient {
    public static void main(String[] args) {
        // Адрес сервера и порт, к которому мы будем подключаться
        String serverAddress = "localhost"; // Используем localhost для локального тестирования
        int port = 12345;

        try {
            // Создаем сокет-канал для подключения к серверу
            SocketChannel socketChannel = SocketChannel.open();
            socketChannel.connect(new InetSocketAddress(serverAddress, port));
            System.out.println("Подключено к серверу: " + serverAddress + " на порту " + port);

            // Создаем объект Scanner для чтения ввода пользователя
            Scanner scanner = new Scanner(System.in);

            while (true) {
                // Запрашиваем сообщение у пользователя
                System.out.print("Введите сообщение для сервера (или 'exit' для выхода): ");
                String message = scanner.nextLine();

                // Если пользователь ввел 'exit', выходим из цикла
                if (message.equalsIgnoreCase("exit")) {
                    break;
                }

                // Преобразуем сообщение в массив байтов
                ByteBuffer buffer = ByteBuffer.wrap(message.getBytes());
                // Отправляем сообщение серверу
                socketChannel.write(buffer);
                System.out.println("Сообщение отправлено серверу: " + message);

                // Очищаем буфер для чтения ответа
//ByteBuffer используется для хранения данных в байтовом формате, что позволяет работать с сетевыми соединениями и другими потоками ввода-вывода
                ByteBuffer responseBuffer = ByteBuffer.allocate(256);
                // Читаем ответ от сервера
                socketChannel.read(responseBuffer);
                responseBuffer.flip(); // Подготавливаем буфер для чтения
//limit - возвращает текущее значение лимита буфера
                String response = new String(responseBuffer.array(), 0, responseBuffer.limit());
                System.out.println("Ответ от сервера: " + response);
            }

            // Закрываем сокет-канал и сканер
            socketChannel.close();
            scanner.close();
            System.out.println("Клиент завершил работу.");
        } catch (IOException e) {
            e.printStackTrace(); // Выводим информацию об ошибке
        }
    }
}
