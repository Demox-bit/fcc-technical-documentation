import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.net.InetSocketAddress;
import java.util.Iterator;
import java.util.Set;

public class NioServer {
    public static void main(String[] args) {
        // Порт, на котором сервер будет слушать входящие соединения
        int port = 12345;

        try {
            // Создаем селектор для управления несколькими каналами
            Selector selector = Selector.open();

            // Создаем серверный сокет и привязываем его к порту
            ServerSocketChannel serverSocketChannel = ServerSocketChannel.open();
            serverSocketChannel.bind(new InetSocketAddress(port));
            serverSocketChannel.configureBlocking(false); // Устанавливаем неблокирующий режим //В неблокирующем режиме операции ввода-вывода (например, чтение или запись) не будут блокировать выполнение программы, если данные недоступны.Это позволяет серверу обрабатывать несколько соединений одновременно, не ожидая, пока данные станут доступны.

            // Регистрируем серверный сокет в селекторе для обработки входящих соединений
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT);
            System.out.println("Сервер запущен и слушает на порту " + port);

            while (true) {
                // Ожидаем событий на каналах
                selector.select();

                // Получаем набор ключей, соответствующих событиям, произошедшим на зарегистрированных каналах Когда селектор обнаруживает, что одно или несколько зарегистрированных соединений готовы для обработки (например, новое соединение или доступные данные для чтения), он добавляет соответствующие ключи в этот набор. 
                Set<SelectionKey> selectedKeys = selector.selectedKeys();
//Итератор позволяет пройтись по всем событиям, которые произошли, и обработать каждое из них. 
                Iterator<SelectionKey> iterator = selectedKeys.iterator();

                while (iterator.hasNext()) {
                    SelectionKey key = iterator.next();

                    // Если это событие - новое соединение
                    if (key.isAcceptable()) {
                        // Принимаем новое соединение
                        SocketChannel clientChannel = serverSocketChannel.accept();
                        clientChannel.configureBlocking(false); // Устанавливаем неблокирующий режим
                        clientChannel.register(selector, SelectionKey.OP_READ); // Регистрируем канал для чтения
                        System.out.println("Клиент подключился: " + clientChannel.getRemoteAddress());
                    }

                    // Если это событие - данные для чтения
                    if (key.isReadable()) {
                        SocketChannel clientChannel = (SocketChannel) key.channel();
                        ByteBuffer buffer = ByteBuffer.allocate(256); // Создаем буфер для чтения данных
                        int bytesRead = clientChannel.read(buffer); // Читаем данные из канала

                        if (bytesRead == -1) {
                            // Если клиент закрыл соединение
                            System.out.println("Клиент отключился: " + clientChannel.getRemoteAddress());
                            clientChannel.close();
                        } else {
                            // Обрабатываем полученные данные
                            String message = new String(buffer.array()).trim();
                            System.out.println("Получено сообщение от клиента: " + message);

                            // Отправляем ответ клиенту
                            String response = "Сервер получил: " + message;
                            ByteBuffer responseBuffer = ByteBuffer.wrap(response.getBytes());
                            clientChannel.write(responseBuffer); // Отправляем ответ
                        }
                    }

                    // Удаляем обработанный ключ из набора
                    iterator.remove();
                }
            }
        } catch (IOException e) {
            e.printStackTrace(); // Выводим информацию об ошибке
        }
    }
}
