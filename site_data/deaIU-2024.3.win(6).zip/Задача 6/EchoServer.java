import java.io.*;
import java.net.*;

public class EchoServer {
    public static void main(String[] args) {
        int port = 12345; // Порт, на котором будет слушать сервер

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Сервер запущен и ожидает подключения...");

            while (true) {
                // Ожидание подключения клиента
                Socket clientSocket = serverSocket.accept();
                System.out.println("Клиент подключен: " + clientSocket.getInetAddress());

                // Обработка клиента в отдельном потоке
                new Thread(new ClientHandler(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
//Класс ClientHandler реализует интерфейс Runnable, что позволяет ему быть выполненным в отдельном потоке. Это позволяет серверу одновременно обрабатывать несколько клиентов.
class ClientHandler implements Runnable {
    private Socket clientSocket;

    public ClientHandler(Socket socket) {
//Это позволяет классу ClientHandler использовать этот сокет для чтения и записи данных.
        this.clientSocket = socket;
    }

    @Override
    public void run() {
        try (
//Этот поток используется для чтения данных, отправленных клиентом. Мы оборачиваем InputStream сокета в InputStreamReader, а затем в BufferedReader для удобного чтения строк.
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
//Этот поток используется для отправки данных обратно клиенту. Мы оборачиваем OutputStream сокета в PrintWriter, где второй параметр true указывает, что данные должны быть автоматически сброшены (отправлены) после каждого вызова метода println().
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
        ) {
//хранение строк полученных от клиента
            String inputLine;

            // Чтение сообщения от клиента и отправка его обратно
            while ((inputLine = in.readLine()) != null) {
                System.out.println("Получено от клиента: " + inputLine);
                out.println(inputLine); // Отправка сообщения обратно клиенту
            }
        } catch (IOException e) {
            e.printStackTrace();
// мы гарантируем, что сокет будет закрыт после завершения работы с клиентом, чтобы освободить ресурсы. 
        } finally {
            try {
                clientSocket.close(); // Закрытие сокета клиента
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
