import java.io.*;
import java.net.*;

public class EchoClient {
    public static void main(String[] args) {
        String hostname = "localhost"; // Адрес сервера
        int port = 12345; // Порт, на котором работает сервер

        try (Socket socket = new Socket(hostname, port);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in))) {

            String userInput;

            System.out.println("Введите сообщение для отправки на сервер (или 'exit' для выхода):");

            // Чтение пользовательского ввода и отправка на сервер
            while ((userInput = stdIn.readLine()) != null) {
                out.println(userInput); // Отправка сообщения на сервер
                String response = in.readLine(); // Ожидание ответа от сервера
                System.out.println("Ответ от сервера: " + response);

                if ("exit".equalsIgnoreCase(userInput)) {
                    break; // Выход из цикла, если пользователь ввел 'exit'
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
